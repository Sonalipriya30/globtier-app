<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class FileController extends Controller
{
    public function index()
{
    return view('index');
}

public function store(Request $request)
{
    if ($request->hasFile('file')) {
        $file = $request->file('file');
        $path = $file->store('uploads');

        $fileModel = new File();
        $fileModel->name = $file->getFileOriginalName();
        $fileModel->path = $path;
        $fileModel->save();
    }
    return redirect()->back()->with('success', 'Files uploaded successfully.');
}

public function delete($filename)
{
    $file = File::find($id);
    Storage::delete($file->path);
    $file->delete();
    return redirect()->back()->with('success', 'File deleted successfully.');
}

public function download($filename)
{
    $path = storage_path('app/' . $filename);

    if (!file_exists($path)) {
        abort(404);
    }

    $headers = [
        'Content-Type' => 'application/octet-stream',
        'Content-Disposition' => 'attachment; filename="' . $filename . '"',
    ];

    return response()->download($path, $filename, $headers);
}

}
